<?php wp_head(); ?>
<?php wp_footer(); ?>