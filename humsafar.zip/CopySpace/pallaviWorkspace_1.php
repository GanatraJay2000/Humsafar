<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">  
  <link href='https://fonts.googleapis.com/css?family=Aclonica' rel='stylesheet'>
  <style>
   .one{
    background-color: #012e29;
    height:300px
   }

   .container{
    text-align:center;
    line-spacing:1px;
   }
   .container .two{
 			font-family: 'Aclonica';
      font-size: 22px;
		}
  </style>
</head>
<body>  
<div class="one">
</div>
<div class="container">
  <div>
      <br>
      <p class="two">  We Plan Your Unforgettable Moments </p>
      <h4> EXCLUSIVE DESTINATION WEDDING PLANNERS & EVENT DESIGNERS </h4>
      <p>Humsafar Wedding is all about curating precisely those special moments of your life that <br>
      get etched in the brain as beautiful and adorable memories. Whether it be the memory <br>
      of Bidding farewell to the oldest Cog of the company or the Dream wedding that you<br>
      always planned in your head, We Humsafars are always with you in every moment.</p>

      <h4>ALWAYS <br>CONSIDERED</h4>
      <p>Dubai  |  Mumbai  |  Udaipur  |  Jaipur  |  Raigarh  |  Raipur  |  Bhilai</p>
  </div>
   
</div>

</body>
</html>
